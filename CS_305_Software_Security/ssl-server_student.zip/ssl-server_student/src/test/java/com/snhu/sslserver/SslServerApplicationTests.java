package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = SslServerApplication.class)
class SslServerApplicationTests {

	@Test
	void contextLoads() {
		// System.out.println("Hello!");
	}

}
