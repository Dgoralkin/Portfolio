# Project_Three_Grocery_Tracking
App to read sold items from a file and outputs the quantity of sold items per day.

// TODO: 
