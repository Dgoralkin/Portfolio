/*
#include <iostream>
#include <string>
#include "CornerItem.h"

using namespace std;
/*
// Constructor.
Item::Item(string product) {
	// Set class variables.
	this->product = product;
	// cout << this << endl;
}

// Destructor.
Item::~Item() {
	// cout << endl << "Curr Object Deleted: " << this;
}
*/
/*
// Getters	----------------------------
// Returns product's name.
string Item::GetProductName() const {
	return this->product;
}
*/